
const message = document.querySelector("#message");
const nameInput = document.querySelector("#nameInput");
const welcomeBtn = document.querySelector("#welcomeBtn");
const checkBtn = document.querySelector("#checkBtn");
const result = document.querySelector("#result");
const counter = document.querySelector(".counter");

let moveCount = 0;

welcomeBtn.onclick = function () {
  const studentName = nameInput.value;
  message.innerHTML = "Welcome, " + studentName;
};

checkBtn.onclick = function () {
  const age = Number(prompt("Enter your age:"));
  const sure = confirm("Are you sure you want to continue?");

  if (sure) {
    let output = "";

    switch (true) {
      case age >= 18:
        output = "You are allowed";
        break;
      case age >= 13 && age <= 17:
        output = "You need permission";
        break;
      case age < 13:
        output = "You are too young";
        break;
      default:
        output = "Invalid age entered";
    }

    result.innerHTML = output;
  }
};


welcomeBtn.onmousemove = function () {
  moveCount++;
  counter.innerHTML = moveCount;
};